#ifndef INSTRUCTOR_H
#define INSTRUCTOR_H

#include <iostream>
#include <string>
#include <list>
#include "MyArray.h"
#include "Course.h"
#include "Student.h"

class Instructor {
public:
  Instructor();
  Instructor(std::string n);
  Instructor(std::string n, std::string d);

  std::string getName() const;
  void setName(std::string n);

  std::string getDepartment();
  void setDepartment(std::string d);

  void addCourse();
  void dropCourse();
  void display();


protected:
  MyArray<Course*>object;
  std::string name;
  std::string department;

};

#endif

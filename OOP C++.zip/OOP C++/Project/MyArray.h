#ifndef MYARRAY_H
#define MYARRAY_H

#include <iostream>
#include <cassert>
#include "Student.h"
#include "Course.h"
#include "Instructor.h"


template <typename T>
class MyArray{
public:
  MyArray();
  MyArray(int m);
  T& operator[](int index);
  int getSize() const;
  int getCapacity() const;


  MyArray(const MyArray &m);
  MyArray<T>& operator=(const MyArray& m);
  ~MyArray();

  void grow();
  void push_back(T e);
  void erase(int element);
  int  getIndex(T value);

private:
  T   *data;
  int capacity;
  int size;
};

template <typename T>
MyArray<T>::MyArray(): MyArray(1) {
}

template <typename T>
MyArray<T>::MyArray(int c) {
  assert(c > 0);
  size = 0;
  capacity = c;
  data = new T[capacity];
}

template <typename T>
MyArray<T>::~MyArray(){
  delete [] data;
}

template <typename T>
MyArray<T>::MyArray(const MyArray& m):
capacity(m.capacity),
size(m.size), data(new T(m.data)) {
  for(int i = 0; i<size; i++){
    data[i] = m[i];
  }
}

template <typename T>
MyArray<T>& MyArray<T>::operator=(const MyArray& m){
  if(this != &m){
    if(capacity != m.capacity){
      delete [] data;
      capacity = m.capacity;
      data = new int[m.capacity]();
    }
    size = m.size;
    for(int i=0; i<size; i++){
      data[i] = m[i];
    }
  }
  return *this;
}

template <typename T>
T& MyArray<T>::operator[](int index){
  assert (index >= 0 && index < size);
  return data[index];
}

template <typename T>
int MyArray<T>::getSize() const {
  return size;
}

template <typename T>
int MyArray<T>::getCapacity() const{
  return capacity;
}

template <typename T>
void MyArray<T>::grow(){
  int newCapacity = capacity * 2 + 1;
  T* newarray = new T[newCapacity];
  for(int i = 0; i < capacity; i++)
    newarray[i] = data[i];
  delete[] data;
  data = newarray;
  capacity = newCapacity;
}

template <typename T>
void MyArray<T>::push_back(T e){
  if(size == capacity){
   grow();
}
  data[size++] = e;
}

template <typename T>
int MyArray<T>::getIndex(T value){
       for(int i = 0; i < size; i++ ){
         if(data[i] == value)
          return i;
       }
           return -1;
         }


template <typename T>
void MyArray<T>::erase(int index){
  for(int i = index; i<size-1; i++){
    data[i] = data[i+1];
      }
      size--;
    }

template <typename T>
void printHeap(MyArray<T> &object){
  for(int i= 0; i<object.getSize(); i++){
    std::cout << *(object[i]) << " ";
  }
  std::cout << std::endl;
}

#endif

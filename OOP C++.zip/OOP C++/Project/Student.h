#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <string>
#include <list>
#include <vector>
#include "MyArray.h"
#include "Course.h"

class Course;
class Student {
public:
  Student();
  Student(std::string n);

  std::string getName() const;
  void setName(std::string n);

  void addCourse();
  void dropCourse();

  void display() const;
  friend  std::ostream& operator<<(std::ostream& cout, const Student& s);

protected:
  std::string name;
  MyArray<Course*>object;
};

#endif

// p1.cpp - F. Rahman
#include <iostream>
using namespace std;


void countdown (int n) {

  for (int i = n; i >= 1; i--) {
  cout << i << " ";
  }
    cout << endl;
      }


int main () {

  countdown (10);

  return 0;
}

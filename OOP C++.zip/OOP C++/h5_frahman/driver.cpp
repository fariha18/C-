// p1.cpp - F. Rahman

#include "RationalNumber.h"
#include <iostream>
using namespace std;

int main() {
    cout << endl;


    RatNum r1(1,2), r2(1,6), r3(2,5);
    RatNum r4(3,0);


    cout << endl;
    return 0;
}

#include "Course.h"


Course::Course(){};
Course::Course(std::string n, std::string in): name(n), instructor(in) { name = n; instructor = in;  }

std::string Course::getName()const { return name; }
void Course::setName(std::string n) { name = n;}

std::string Course::getInstructor() { return <Instructor*>object; }
void Course::setInstructor(std::string in) { instructor = <Instructor*>object;}


void Course::addStudent(){
  Student* s;
  Student* addCourse(MyArray<Student*>object);
  }


void Course::dropStudent(){
  MyArray<Student*>object;
  int *temp = Course;
  delete temp;

  }

void Course::dropInstructor(){
  int *temp = Instructor;
  delete temp;
  Instructor* i = "Staff";
}


void Course:: display(){std::cout << instructor << " " << MyArray<Student*>[object] << std::endl;}


std::ostream& operator<<(std::ostream& cout, const Student& s){
std::cout << s.name << std::endl;
return cout;
}

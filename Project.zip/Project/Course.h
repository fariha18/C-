#ifndef COURSE_H
#define COURSE_H

#include <iostream>
#include <string>
#include <list>
#include <vector>
#include "MyArray.h"
#include "Student.h"
#include "Instructor.h"

class Student;
class Course{
public:
  Course();
  Course(std::string n, std::string in);
  std::string getName() const;
  void setName(std::string n);

  std::string getInstructor();
  void setInstructor(std::string in);

  void addStudent();
  void dropStudent();
  void dropInstructor();
  void display();

protected:
  MyArray<Student*>object;
  std::string name;
  std::string *instructor;

};

#endif

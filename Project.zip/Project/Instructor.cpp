#include "Instructor.h"

Instructor::Instructor("Staff"){};
Instructor::Instructor(std::string n): name(n){ name = n;}
Instructor::Instructor(std::string n, std::string d):name(n), department(d) { name = n; department = d;  }

std::string Instructor::getName() const { return name; }
void Instructor::setName(std::string n) { name = n;}

std::string Instructor::getDepartment() { return department; }
void Instructor::setDepartment(std::string d) { department = d;}


void Instructor::addCourse(){
      MyArray<Course*>object;

      for(int i=0; i<object.getCapacity(); i++) {
          object.push_back(object);
      }
         object.getIndex(object);
         printHeap(Course);
      }

void Instructor::dropCourse(){
  for(int i = 0; i < object.getCapacity(); i++){
    MyArray<Course*>object;
    int *temp = Course;
    delete temp;
    Instructor* i = "Staff";
  }
}

void Instructor:: display(){std::cout << name << " " << department << " " << MyArray<Course*>[object] << std::endl;}

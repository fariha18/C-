#include "Student.h"


Student::Student(){};
Student::Student(std::string n): name(n) { name = n; }

std::string Student::getName() const { return name; }
void Student::setName(std::string n) { name = n;}


void Student::addCourse(){

MyArray<Course*>object;
for(int i=0; i<object.getCapacity(); i++) {
       Course *c; /*= new Course( "ET-580/D2" )*/
       object.push_back( c );
    }
    printHeap(Course);
  }

void Student::dropCourse(){
  MyArray<Student*>object;
  int *temp = Course;
  delete temp;
  Course* dropStudent();
}


void Student:: display() const { std::cout << name << " " <<  MyArray<Course*>[object]<< std::endl; }


std::ostream& operator<<(std::ostream& cout, const Student& s){
std::cout << s.name << std::endl;
return cout;
}
